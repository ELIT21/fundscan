the balance scaner is a private wif key générétor and address bitcoin fixed with Wif
key is used for verify balance of this wif key the wif key, address and balance
is saved on verified_addresses.txt see the balance of address is over 0.00000000 for 
support me creation this is me bitcoin address 13gquZnD59CygqYYvf3jjsCo5GfQ7psEHm


cmd

or 

terminal ubuntu

cd (repertory of folder) 

pip install requirements.txt

python fundscan.py