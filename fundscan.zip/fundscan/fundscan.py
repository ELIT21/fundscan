import os
import binascii
import hashlib
import base58
import threading
import requests
import concurrent.futures

# Fonction pour générer une clé privée aléatoire de 32 octets (256 bits)
def generate_private_key():
    return os.urandom(32)

# Fonction pour générer la clé privée au format WIF
def private_key_to_wif(private_key):
    extended_key = b'\x80' + private_key  # Préfixe 0x80 pour une clé privée principale
    checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
    wif_private_key = base58.b58encode(extended_key + checksum).decode('utf-8')
    return wif_private_key

# Fonction pour générer l'adresse Bitcoin correspondante
def private_key_to_bitcoin_address(private_key):
    public_key = hashlib.sha256(private_key).digest()
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(public_key)
    ripemd160_hash = ripemd160.digest()
    address = b'\x00' + ripemd160_hash  # Préfixe 0x00 pour une adresse Bitcoin principale
    checksum = hashlib.sha256(hashlib.sha256(address).digest()).digest()[:4]
    bitcoin_address = base58.b58encode(address + checksum).decode('utf-8')
    return bitcoin_address

# Fonction pour vérifier le solde d'une adresse Bitcoin
def get_balance(address):
    url = f"https://blockchain.info/address/{address}?format=json"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        balance_btc = data["final_balance"] / 100000000.0
        return balance_btc
    else:
        return None

# Nombre de clés à générer
num_keys_to_generate = 999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999  # Vous pouvez ajuster ce nombre à votre convenance

# Nombre de threads à utiliser pour la génération de clés et la vérification
num_threads = 1  # Vous pouvez ajuster le nombre de threads

# Verrou pour synchroniser l'accès aux fichiers partagés
file_lock = threading.Lock()

# Fonction pour générer des clés privées, des adresses Bitcoin, vérifier les soldes et afficher les résultats
def generate_verify_and_save_keys(thread_id, keys_per_thread):
    start_index = thread_id * keys_per_thread
    end_index = (thread_id + 1) * keys_per_thread

    with file_lock:  # Utiliser le verrou pour éviter les conflits d'accès aux fichiers partagés
        with open('verified_addresses.txt', 'a') as verified_file:
            for i in range(start_index, end_index):
                private_key = generate_private_key()
                wif_private_key = private_key_to_wif(private_key)
                bitcoin_address = private_key_to_bitcoin_address(private_key)
                balance = get_balance(bitcoin_address)
                if balance is not None and balance > 0.00000000:
                    verified_file.write(f"Adresse: {bitcoin_address}, Solde: {balance} BTC, Clé privée WIF: {wif_private_key}\n")
                    print(f"Adresse vérifiée: {bitcoin_address}, Solde: {balance} BTC, Clé privée WIF: {wif_private_key} (par thread {thread_id})")
                elif balance is not None:
                    print(f"Adresse vérifiée: {bitcoin_address}, Solde insuffisant: {balance} BTC (par thread {thread_id})")
                else:
                    print(f"Impossible de vérifier l'adresse: {bitcoin_address} (par thread {thread_id})")

# Calculez le nombre de clés à générer par thread
keys_per_thread = num_keys_to_generate // num_threads

# Créez et lancez les threads pour la génération et la vérification des clés
threads = []
for i in range(num_threads):
    thread = threading.Thread(target=generate_verify_and_save_keys, args=(i, keys_per_thread))
    threads.append(thread)
    thread.start()

# Attendez que tous les threads se terminent
for thread in threads:
    thread.join()

print(f"{num_keys_to_generate} paires de clés privées WIF générées, adresses Bitcoin vérifiées avec un solde supérieur à 0.00000000 BTC, et les résultats enregistrés dans 'verified_addresses.txt'")